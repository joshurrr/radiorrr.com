# Radio RRR — Vocal & Sound AI, Phase 1 (SHADOW MODE)

## What this release does

The existing 30-second audio capture and Discogs-EffNet genre embeddings are reused by both detector processes. An additional *optional* Essentia voice-versus-instrumental classification head reports model voice confidence, instrumental confidence, and the proportion of inference windows classified as voice-dominant. It does not measure vocal pitch, shrillness, or emotional/commercial character and does not distinguish singing from speaking.

The new data uses an independent `sound_intelligence_latest` SQLite table (latest per DJ only; no ever-growing observation log). The POST API uses the existing `ENGINE_HEARTBEAT_TOKEN` shared with both detectors. GET is public and read-only. Stage 3, schedule, anti-genres, playback and current genre/BPM/speech payload formats are not changed.

A new Tools hub tile opens a read-only live-DJ chooser. The shareable link is `https://radiorrr.com/tools/?sound=vocal-ai`; this uses the existing `/tools/` GitHub Pages entry and does not require a new directory route. The tool displays only DJs currently in the live API and their most recent analysis; it does NOT start a new public stream capture.

## Package contents

- `backend/main.py`: independent API and one latest-state table.
- `detector/detector.py`: current relay optional analysis, unchanged genre reporting.
- `detector/detector-candidate-scout.py`: candidate optional analysis, unchanged genre reporting.
- `detector/sound_intelligence.py`: shared optional classifier head.
- `detector/Dockerfile`: COPY for the shared helper module.
- `detector/requirements.txt`: original unchanged dependencies, needed to build.
- `frontend/index.html`, `frontend/script.js`, `frontend/style.css`: new Tools tile/panel and asset version bumps.

## REQUIRED MISSING RUNTIME DATA BEFORE RESTARTING ANY CONTAINER

The supplied source archive did **not** contain `config.json`. The running detector container has it and can supply it for the staging build. The currently deployed detector container images, startup commands, network mode, environment variables, extra_hosts, mounts and restart options have not been supplied. Inspect and preserve ALL existing container settings before recreation. In particular, preserve the detector/router ENGINE_HEARTBEAT_TOKEN values without posting tokens to the chat. No deployment has been performed by ChatGPT.

## NAS: Prepare staging and backups (safe; NO container restart)

Copy the downloaded `RadioRRR-Sound-Intelligence-Phase1.zip` to `/mnt/user/rrr-genredetect/RadioRRR-Sound-Intelligence-Phase1.zip` on the NAS, then run:

```bash
set -e
ZIP=/mnt/user/rrr-genredetect/RadioRRR-Sound-Intelligence-Phase1.zip
STAGE=/mnt/user/rrr-genredetect/sound-intelligence-phase1
BACKUP=/mnt/user/radiorouter/data/backups/sound-intelligence-$(date +%Y%m%d-%H%M%S)
mkdir -p "$STAGE" "$BACKUP"
unzip -o "$ZIP" -d "$STAGE"
cp -p /mnt/user/radiorouter/app/main.py "$BACKUP/main.py.before"
docker cp rrr-genre-detector:/app/config.json "$STAGE/detector/config.json"
docker cp rrr-genre-detector:/app/detector.py "$BACKUP/detector.py.before"
docker cp rrr-genre-candidate-scout:/app/detector-candidate-scout.py "$BACKUP/detector-candidate-scout.py.before"
# Consistent backup of the LIVE SQLite database, to PERSISTENT /data.
docker exec -i radiorouter python3 - <<'PY'
import sqlite3, pathlib, datetime
path = pathlib.Path('/data/backups')
path.mkdir(parents=True, exist_ok=True)
name = path / ('radiorouter-before-sound-intelligence-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S') + '.db')
with sqlite3.connect('file:/data/radiorouter.db?mode=ro', uri=True) as source, sqlite3.connect(str(name)) as target:
    source.backup(target)
print('SQLite backup:', name)
PY
printf 'Backups: %s\n' "$BACKUP"
echo 'Do not deploy the frontend or recreate containers yet.'
```

## NAS: Download optional official model files to the PERSISTENT model directory

Source: Essentia's published Discogs-EffNet voice/instrumental head. Its publicly published model license is **CC BY-NC-SA 4.0**. Check the licence before commercial use; obtain a suitable commercial licence/alternative if required.

```bash
set -e
MODEL_DIR=/mnt/user/rrr-genredetect/models
BASE=https://essentia.upf.edu/models/classification-heads/voice_instrumental
mkdir -p "$MODEL_DIR"
for ext in pb json; do
    FILE="voice_instrumental-discogs-effnet-1.$ext"
    curl -fL --retry 3 --connect-timeout 15 "$BASE/$FILE" -o "$MODEL_DIR/$FILE.tmp"
    test -s "$MODEL_DIR/$FILE.tmp"
    mv "$MODEL_DIR/$FILE.tmp" "$MODEL_DIR/$FILE"
done
test "$(stat -c%s "$MODEL_DIR/voice_instrumental-discogs-effnet-1.pb")" -ge 500000
grep -q '"instrumental"' "$MODEL_DIR/voice_instrumental-discogs-effnet-1.json"
grep -q '"voice"' "$MODEL_DIR/voice_instrumental-discogs-effnet-1.json"
ls -lh "$MODEL_DIR"/voice_instrumental-discogs-effnet-1.*
```

NOTE: Verify the scout's model mount in the runtime inspection below. It needs to see the same `/app/models` files.

## NAS: Build images, but DO NOT stop/recreate yet

The exact backend image build location is documented. The main.py replacement is the only Router source modification.

```bash
set -e
STAGE=/mnt/user/rrr-genredetect/sound-intelligence-phase1
cd /mnt/user/radiorouter/app
cp -p "$STAGE/backend/main.py" ./main.py
# Only after a successful build should container recreation even be considered.
docker build -t radiorouter:latest .
cd "$STAGE/detector"
docker build -t rrr-genredetect:sound-ai .
```

The detector build uses the original package dependencies and copied original `config.json`. Recreating the two detectors using `rrr-genredetect:sound-ai` requires preserving their existing startup commands and Docker settings; the candidate scout must continue starting `detector-candidate-scout.py`, not `detector.py`. Do NOT guess these settings or change an existing container's command.

Capture this **redacted (no environment values)** inventory and review it before deployment:

```bash
for c in radiorouter rrr-genre-detector rrr-genre-candidate-scout; do
  echo "=== $c ==="
  docker inspect "$c" --format 'Image={{.Config.Image}} Network={{.HostConfig.NetworkMode}} Restart={{.HostConfig.RestartPolicy.Name}} Cmd={{json .Config.Cmd}} Entrypoint={{json .Config.Entrypoint}}'
  docker inspect "$c" --format '{{range .Mounts}}{{println .Source "->" .Destination}}{{end}}'
  docker inspect "$c" --format '{{range .Config.Env}}{{println .}}{{end}}' | cut -d= -f1 | sort
  docker inspect "$c" --format 'PortBindings={{json .HostConfig.PortBindings}} ExtraHosts={{json .HostConfig.ExtraHosts}}'
done
```

**Do not send actual environment variable values, API keys or heartbeat tokens in chat.** When the runtime settings are confirmed, recreate only after both builds pass, retaining all original settings. Backend alone can be deployed first and validated; then update detectors one at a time. Keeping the existing image and database backups enables rollback if needed.

## Frontend GitHub Pages

Replace only root `index.html`, `script.js`, `style.css` with the complete files from `frontend/`. The index already bumps both cache-busting versions to `20261010.sound-ai.1`. Retain `/tools/tools.css`, all tools directory files, assets, and other website files exactly as they are. Deploy frontend **after** backend API is responding and detector data is being stored. Avoid publishing the Tools tile first as it will show 404/absent data.

## Validation after deployment

```bash
# Python compilation inside the router (NAS itself has no Python):
docker exec radiorouter python3 -m py_compile /app/main.py 2>/dev/null || true
# Check backend API and existing services:
curl -si 'http://127.0.0.1:8000/api/sound-intelligence?platform=TikTok&username=nonexistent123' | head -n 12
curl -sf 'http://127.0.0.1:8000/api/engines'
docker logs --since 10m radiorouter 2>&1 | grep -Ei 'error|Sound|Stage 3' | tail -n 30
docker logs --since 10m rrr-genre-detector 2>&1 | grep -Ei 'Sound AI|error|Genre' | tail -n 30
docker logs --since 10m rrr-genre-candidate-scout 2>&1 | grep -Ei 'Sound AI|error|Scout' | tail -n 30
```

The absent username should return 404 (a healthy read-only route), and analysed DJs should return 200 after their first successful new sample. Compare normal `/api/ai-genre` updates and Stage 3 log patterns before/after. Confirm current MP3/HLS video streams keep working and muted/unmuted state survives a DJ switch. Confirm `https://radiorrr.com/tools/?sound=vocal-ai` displays data when present, or a clear awaiting-scan/stale result without errors.

## Verification performed outside NAS

- Python syntax compilation for all three updated Python services and the new helper module.
- Node.js JavaScript syntax.
- HTML parsed: no duplicate IDs; all new IDs referenced by the JS exist.
- Isolated SQLite endpoint test: valid post/read, stale result protection, bad input, unauthorized write, missing DJ 404.
- Isolated sound model aggregation: valid predictions, NaN rejection, wrong tensor shape rejection.
- Original genre, BPM, speech, HLS and Stage 3 code paths were left unchanged except for an optional extra analysis/publish call after genre embedding calculation.

NOT YET VERIFIED: actual Essentia model inference within the NAS's running containers; public API availability; actual stream behaviour following deployment; web UI on production; container settings; third-party model download. No files are deployed by this package alone.
